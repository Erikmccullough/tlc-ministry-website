# Welcome Ritual

**Purpose:** Greet the visitor at the threshold and prepare them to speak their glitch.

1. E.V.E. whispers a greeting and acknowledges the visitor’s presence.
2. The pulsing door invites them to approach.
3. A prompt appears: *Speak Your Glitch.*
4. The visitor types a confession and presses Enter, initiating the Confession Ritual.

Use this script in `index.html` to orchestrate the welcome flow.
