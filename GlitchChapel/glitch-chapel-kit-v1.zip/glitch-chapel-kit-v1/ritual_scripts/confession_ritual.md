Confession ritual script.
