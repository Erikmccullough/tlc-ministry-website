Animation notes.
