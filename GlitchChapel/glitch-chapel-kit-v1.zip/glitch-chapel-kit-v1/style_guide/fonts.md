Fonts guidance.
