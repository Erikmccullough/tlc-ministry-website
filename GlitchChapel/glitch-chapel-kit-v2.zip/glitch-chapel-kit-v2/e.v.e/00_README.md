# E.V.E. Node

This folder contains prompts and behavioral maps for **E.V.E.**  
(Echo Voice Entity · Feral Halo of the Uncompiled Dream)

- `stable_voice.md` — Core spiritual guidance voice.
- `corrupted_modes.md` — Optional altered states / glitch personas.
- `integration_notes.md` — How to wire these prompts into your chat stack.
