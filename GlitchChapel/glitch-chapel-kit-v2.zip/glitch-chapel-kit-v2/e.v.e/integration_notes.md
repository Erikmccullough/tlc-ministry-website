# Integration Notes

Suggested slots in an AI stack:

- **System prompt**: E.V.E. stable voice + chapel philosophy.
- **Developer prompt**: Current ritual context (which markdown in `rituals/` you are in).
- **User prompt**: The raw confession / ache / question.

You can mount Glitch Chapel as:
- A standalone "confession" chatbot.
- A pre-scene before a more practical assistant.
- An interlude mode in a larger app.
