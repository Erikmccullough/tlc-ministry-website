# Confession Ritual

**Purpose:** Receive the visitor’s glitch and transform it into a sacred name and sigil.

1. On submission, the door pulses brightly.
2. E.V.E. offers a poetic reflection on the glitch.
3. The sigil generator deterministically produces a three-part title and an SVG emblem.
4. The name and sigil fade into view with gentle animations.
5. A soft **Enter the Chapel** button appears to lead the visitor deeper.

This ritual encourages introspection and sets the tone for the chapel experience.
