# Undercroft

The Undercroft is where things are **kept** or **let go**.

Think of this folder as a conceptual and technical basement:
- Memory burning patterns
- Shadow archives
- Descent / return sequences
