# Visual System

This folder holds visual primitives for the Chapel:

- Base sigil SVGs
- Altar frames / borders
- Color and glow references

Use these as starting points, not as a locked design system.
