Welcome ritual script.
