Deterministic sigil + sacred title generator overview.
